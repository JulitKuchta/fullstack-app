package com.example.pasir_kuchta_julita;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaSiRKuchtaJulitaApplicationTests {

    @Test
    void contextLoads() {
    }

}
