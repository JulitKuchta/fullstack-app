package com.example.pasir_kuchta_julita.repository;

import com.example.pasir_kuchta_julita.model.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long> {}