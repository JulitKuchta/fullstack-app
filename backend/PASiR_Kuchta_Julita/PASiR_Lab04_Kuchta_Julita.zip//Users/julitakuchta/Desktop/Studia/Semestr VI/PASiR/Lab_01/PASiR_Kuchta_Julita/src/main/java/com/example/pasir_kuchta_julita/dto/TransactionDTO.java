package com.example.pasir_kuchta_julita.dto;


import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
public class TransactionDTO {

    @Setter
    @NotNull(message = "Kwota nie może być pusta.")
    @Min(value = 1, message = "Kwota musi być większa niż 0.")
    private Double amount;

    @Setter
    @Size(max = 50, message = "Maksymalny rozmiar tagu to 50 znaków.")
    private String tags;

    @Setter
    @Size(max = 255, message = "Maksymalny rozmiar notatki to 255 znaków.")
    private String notes;

    @Setter
    @Pattern(regexp = "INCOME|EXPENSE", message = "Typ to musi być INCOME lub EXPENSE.")
    @NotNull(message = "Ta pozycja jest wymagana.")
    private String type;
}
