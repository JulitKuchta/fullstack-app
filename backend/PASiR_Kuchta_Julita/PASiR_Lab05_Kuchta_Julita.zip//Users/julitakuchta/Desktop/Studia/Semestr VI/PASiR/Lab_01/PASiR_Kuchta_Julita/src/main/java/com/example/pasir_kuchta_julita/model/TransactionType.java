package com.example.pasir_kuchta_julita.model;

public enum TransactionType {
    INCOME,
    EXPENSE
}
