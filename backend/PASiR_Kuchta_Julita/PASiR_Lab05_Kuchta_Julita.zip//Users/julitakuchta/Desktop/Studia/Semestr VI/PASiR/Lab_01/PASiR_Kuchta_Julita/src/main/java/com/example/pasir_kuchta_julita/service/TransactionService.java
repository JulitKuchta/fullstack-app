package com.example.pasir_kuchta_julita.service;

import com.example.pasir_kuchta_julita.dto.BalanceDTO;
import com.example.pasir_kuchta_julita.dto.TransactionDTO;
import com.example.pasir_kuchta_julita.model.Transaction;
import com.example.pasir_kuchta_julita.model.TransactionType;
import com.example.pasir_kuchta_julita.model.User;
import com.example.pasir_kuchta_julita.repository.TransactionRepository;
import com.example.pasir_kuchta_julita.repository.UserRepository;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class TransactionService {

    private final TransactionRepository transactionRepository;
    private final UserRepository userRepository;

    public TransactionService(TransactionRepository transactionRepository, UserRepository userRepository) {
        this.transactionRepository = transactionRepository;
        this.userRepository = userRepository;
    }


    public User getCurrentUser() {
        String email = SecurityContextHolder.getContext().getAuthentication().getName();
        System.out.println(email);
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Nie znaleziono zalogowanego użytkownika"));
    }


    public List<Transaction> getAllTransactions() {
        User user = getCurrentUser();
        return transactionRepository.findAllByUser(user);
    }


    public Transaction getTransactionById(Long id) {
        Transaction transaction = transactionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Nie znaleziono transakcji o ID " + id));


        if (!transaction.getUser().getEmail().equals(getCurrentUser().getEmail())) {
            throw new SecurityException("Brak dostępu do tej transakcji");
        }

        return transaction;
    }


    public Transaction updateTransaction(Long id, TransactionDTO transactionDTO) {
        Transaction transaction = transactionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Nie znaleziono transakcji o ID " + id));


        if (!transaction.getUser().getEmail().equals(getCurrentUser().getEmail())) {
            throw new SecurityException("Brak dostępu do edycji tej transakcji");
        }

        transaction.setAmount(transactionDTO.getAmount());
        transaction.setType(transactionDTO.getType());
        transaction.setTags(transactionDTO.getTags());
        transaction.setNotes(transactionDTO.getNotes());

        return transactionRepository.save(transaction);
    }


    public BalanceDTO getUserBalance(User user, Float days) {
        List<Transaction> userTransactions = transactionRepository.findByUser(user);

        // Jeśli określono liczbę dni, filtruj transakcje według daty
        if (days != null && days > 0) {
            LocalDateTime startDate = LocalDateTime.now().minusDays(days.longValue());
            userTransactions = userTransactions.stream()
                    .filter(transaction -> transaction.getTimestamp() != null &&
                            transaction.getTimestamp().isAfter(startDate))
                    .collect(Collectors.toList());
        }

        double income = userTransactions.stream()
                .filter(t -> t.getType() == TransactionType.INCOME)
                .mapToDouble(Transaction::getAmount)
                .sum();

        double expense = userTransactions.stream()
                .filter(t -> t.getType() == TransactionType.EXPENSE)
                .mapToDouble(Transaction::getAmount)
                .sum();

        return new BalanceDTO(income, expense, income - expense);
    }

    public Transaction createTransaction(TransactionDTO transactionDTO) {
        Transaction transaction = new Transaction();
        transaction.setAmount(transactionDTO.getAmount());


        transaction.setType(transactionDTO.getType());

        transaction.setTags(transactionDTO.getTags());
        transaction.setNotes(transactionDTO.getNotes());
        transaction.setUser(getCurrentUser());
        transaction.setTimestamp(LocalDateTime.now());

        return transactionRepository.save(transaction);
    }

    public Boolean deleteTransaction(Long id) {
        User currentUser = getCurrentUser();

        Transaction transaction = transactionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Nie znaleziono transakcji o ID: " + id));

        if (!transaction.getUser().getId().equals(currentUser.getId())) {
            throw new RuntimeException("Nie możesz usunąć transakcji innego użytkownika");
        }

        try {
            transactionRepository.delete(transaction);
            return true;
        } catch (Exception e) {
            throw new RuntimeException("Nie udało się usunąć transakcji: " + e.getMessage());
        }
    }

    // Dodaj to do TransactionService.java
    public List<Transaction> getFilteredTransactions(String type, String tags, Double minAmount, Double maxAmount, LocalDateTime startDate, LocalDateTime endDate) {
        User currentUser = getCurrentUser();
        List<Transaction> userTransactions = transactionRepository.findByUser(currentUser);

        // Filtrowanie po typie transakcji
        if (type != null && !type.isEmpty()) {
            try {
                TransactionType transactionType = TransactionType.valueOf(type.toUpperCase());
                userTransactions = userTransactions.stream()
                        .filter(t -> t.getType() == transactionType)
                        .collect(Collectors.toList());
            } catch (IllegalArgumentException e) {
                // Ignoruj nieprawidłowy typ
            }
        }

        // Filtrowanie po tagach
        if (tags != null && !tags.isEmpty()) {
            String[] tagList = tags.split(",");
            userTransactions = userTransactions.stream()
                    .filter(t -> {
                        for (String tag : tagList) {
                            if (t.getTags() != null && t.getTags().contains(tag.trim())) {
                                return true;
                            }
                        }
                        return false;
                    })
                    .collect(Collectors.toList());
        }

        // Filtrowanie po minimalnej kwocie
        if (minAmount != null) {
            userTransactions = userTransactions.stream()
                    .filter(t -> t.getAmount() >= minAmount)
                    .collect(Collectors.toList());
        }

        // Filtrowanie po maksymalnej kwocie
        if (maxAmount != null) {
            userTransactions = userTransactions.stream()
                    .filter(t -> t.getAmount() <= maxAmount)
                    .collect(Collectors.toList());
        }

        // Filtrowanie po dacie początkowej
        if (startDate != null) {
            userTransactions = userTransactions.stream()
                    .filter(t -> t.getTimestamp() != null && !t.getTimestamp().isBefore(startDate))
                    .collect(Collectors.toList());
        }

        // Filtrowanie po dacie końcowej
        if (endDate != null) {
            userTransactions = userTransactions.stream()
                    .filter(t -> t.getTimestamp() != null && !t.getTimestamp().isAfter(endDate))
                    .collect(Collectors.toList());
        }

        return userTransactions;
    }
}