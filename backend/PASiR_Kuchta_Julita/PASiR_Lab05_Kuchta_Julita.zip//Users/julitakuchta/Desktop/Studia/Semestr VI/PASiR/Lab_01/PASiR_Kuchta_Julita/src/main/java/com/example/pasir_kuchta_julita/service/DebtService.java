package com.example.pasir_kuchta_julita.service;

import com.example.pasir_kuchta_julita.dto.DebtDTO;
import com.example.pasir_kuchta_julita.encje.Debt;
import com.example.pasir_kuchta_julita.encje.Group;
import com.example.pasir_kuchta_julita.model.User;
import com.example.pasir_kuchta_julita.repository.DebtRepository;
import com.example.pasir_kuchta_julita.repository.GroupRepository;
import com.example.pasir_kuchta_julita.repository.UserRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DebtService {
    private final DebtRepository debtRepository;
    private final GroupRepository groupRepository;
    private final UserRepository userRepository;

    public DebtService(DebtRepository debtRepository, GroupRepository groupRepository, UserRepository userRepository) {
        this.debtRepository = debtRepository;
        this.groupRepository = groupRepository;
        this.userRepository = userRepository;
    }

    public List<Debt> getGroupDebts(Long groupId) {
        return debtRepository.findByGroupId(groupId);
    }

    public Debt createDebt(DebtDTO debtDTO) {
        Group group = groupRepository.findById(debtDTO.getGroupId()).orElseThrow(
                () -> new EntityNotFoundException("Nie znaleziono grupy o id: " + debtDTO.getGroupId())
        );

        User debtor = userRepository.findById(debtDTO.getDebtorId()).orElseThrow(
                () -> new EntityNotFoundException("Nie znaleziono dluznika o id: " + debtDTO.getDebtorId())
        );

        User creditor = userRepository.findById(debtDTO.getCreditorId()).orElseThrow(
                () -> new EntityNotFoundException("Nie znaleziono wierzycie o id: " + debtDTO.getCreditorId())
        );

        Debt debt = new Debt();
        debt.setGroup(group);
        debt.setDebtor(debtor);
        debt.setCreditor(creditor);
        debt.setAmount(debtDTO.getAmount());
        debt.setTitle(debtDTO.getTitle());

        return debtRepository.save(debt);
    }
}
