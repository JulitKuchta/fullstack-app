package com.example.pasir_kuchta_julita.service;

import com.example.pasir_kuchta_julita.dto.GroupDTO;
import com.example.pasir_kuchta_julita.dto.GroupTransactionDTO;
import com.example.pasir_kuchta_julita.encje.Debt;
import com.example.pasir_kuchta_julita.encje.Group;
import com.example.pasir_kuchta_julita.encje.Membership;
import com.example.pasir_kuchta_julita.model.User;
import com.example.pasir_kuchta_julita.repository.DebtRepository;
import com.example.pasir_kuchta_julita.repository.GroupRepository;
import com.example.pasir_kuchta_julita.repository.MembershipRepository;
import com.example.pasir_kuchta_julita.repository.TransactionRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GroupTransactionService {

    private final GroupRepository groupRepository;
    private final MembershipRepository membershipRepository;
    private final DebtRepository debtRepository;

    public GroupTransactionService(GroupRepository groupRepository, MembershipRepository membershipRepository, DebtRepository debtRepository) {
        this.groupRepository = groupRepository;
        this.membershipRepository = membershipRepository;
        this.debtRepository = debtRepository;
    }

    public void addGroupTransaction(GroupTransactionDTO dto, User currentUser){
        Group group = groupRepository.findById(dto.getGroupId()).orElseThrow(
                () -> new EntityNotFoundException("Nie znaleziono grupy")
        );

        List<Membership> members = membershipRepository.findByGroupId(group.getId());

        if(members.isEmpty()){
            throw new IllegalArgumentException("Brak członków w grupie");
        }

        double amountPerUser = dto.getAmount()/members.size();

        for (Membership membership : members) {
            User debtor = membership.getUser();
            if(!debtor.getId().equals(currentUser.getId())){
                Debt debt = new Debt();
                debt.setDebtor(debtor);
                debt.setCreditor(currentUser);
                debt.setGroup(group);
                debt.setAmount(amountPerUser);
                debt.setTitle(dto.getTitle());
                debtRepository.save(debt);
            }
        }

    }
}


