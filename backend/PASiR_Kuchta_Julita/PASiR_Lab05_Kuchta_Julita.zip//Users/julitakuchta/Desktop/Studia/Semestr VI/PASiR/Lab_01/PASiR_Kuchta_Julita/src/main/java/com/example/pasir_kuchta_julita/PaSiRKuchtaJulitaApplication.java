package com.example.pasir_kuchta_julita;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaSiRKuchtaJulitaApplication {

    public static void main(String[] args) {
        SpringApplication.run(PaSiRKuchtaJulitaApplication.class, args);
    }

}
